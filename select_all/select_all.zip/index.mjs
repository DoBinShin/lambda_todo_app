const mysql  = require("mysql");
const config = require("./config.json");

const db = mysql.createConnection({
    host : config.host,
    port : config.port,
    user : config.user,
    password : config.password,
    database : config.database,
    connectionLimit : 60
});

db.connect();

export default handler =  async (event) => {
    try {
        const query =`SELECT id
                           , title
                           , completed 
                        FROM TODO
                    `;
        const res = await db.qeury(query);
        
        return res.json();
    } catch(err) {
        console.log(err);
        err.statusCode = 404;
        err.message = "조회 실패";
        return err;
    } finally {
        conn.release();
    }
}
