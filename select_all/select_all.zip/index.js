const pool = require("./database");

const conn = pool.promise();

const selectAll = async(sql) => {
    try {
        const [row, fields] = await conn.query(sql);
        return row;
    } catch(err) {
        return false;
    } finally {
        conn.releaseConnection();
    }
}


module.exports.handler = async (event) => {
    const query =`SELECT * FROM TODO`;   
    
    try {     
        const res = await selectAll(query);
        return {
            statusCode : 200,
            body : JSON.stringify(res)
        }
    } catch(err) {
        console.log(err);
        err.statusCode = 404;
        err.message = "조회 실패";
        return err;
    } 
}
