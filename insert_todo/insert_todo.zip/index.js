const mysql = require("mysql2");
const {v4: uuidv4} = require("uuid");
const pool = require("./database");

// uuid setting
const uuid = () => {
  const tokens = uuidv4().split('-')
  return tokens[2] + tokens[1] + tokens[0] + tokens[3] + tokens[4];
}

const addTodo = async (event, sql) => {

  const conn = pool.promise();

  try {
    const [row, fields] = await conn.query(sql);
    if(event.body.length == row.length) {
      conn.commit;
      return true;
    }
    conn.rollback;
    return false;
  } catch(err) {
    return false;
  } finally {
    conn.releaseConnection();
  }
}

module.exports.handler = async(event) => {
    
    const query = ` 
      INSERT INTO TODO
      VALUES(?,?,?);
    `;
  
    try {

      if(0 < event.body.length) {            
        let sqls = "";
        
        event.body.forEach(item => {
          sqls += mysql.format(query, [uuid(), item.title, item.completed]);
        });

        const res = await addTodo(event, sqls);
        
        if(res) {
          return {
            statusCode : 200,
            body : {
              message : "SUCCESS"
            }
          }    
        }
        throw new Error("저장 실패!");
      } 
      throw new Error("데이터가 없습니다.");
    } catch(err) {
      console.log(err);
      err.statusCode = 404;
      return err;
    } 
}